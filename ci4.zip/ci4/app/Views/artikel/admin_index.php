<h1><?= $title; ?></h1>

<!-- 🔥 Tombol Logout -->
<a href="<?= base_url('/user/logout'); ?>">Logout</a>

<br><br>

<a href="<?= base_url('/admin/artikel/add'); ?>">+ Tambah Artikel</a>

<br><br>

<!-- 🔥 FORM PENCARIAN -->
<form method="get" class="form-search">
    <input type="text" name="q" value="<?= $q; ?>" placeholder="Cari data">
    <input type="submit" value="Cari" class="btn btn-primary">
</form>

<br>

<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>Judul</th>
        <th>Aksi</th>
    </tr>

    <?php foreach($artikel as $row): ?>
    <tr>
        <td><?= $row['id']; ?></td>
        <td><?= $row['judul']; ?></td>
        <td>
            <a href="<?= base_url('/admin/artikel/edit/' . $row['id']); ?>">Edit</a> |
            
            <a href="<?= base_url('/admin/artikel/delete/' . $row['id']); ?>" 
               onclick="return confirm('Yakin mau hapus data ini?');">
               Delete
            </a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<br>

<!-- 🔥 PAGINATION -->
<?= $pager->only(['q'])->links(); ?>